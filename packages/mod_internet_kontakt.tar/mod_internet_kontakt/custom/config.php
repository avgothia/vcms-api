<?php
$zeigeNichtSenior = false;
$zeigeNichtJubelsenior = false;
$zeigeNichtConsenior = false;
$zeigeNichtFuchsmajor = false;
$zeigeNichtFuchsmajor2 = false;
$zeigeNichtScriptor = false;
$zeigeNichtQuaestor = false;
?>