<?php
header("Location: " . $_GET("to"));
exit;
?>
